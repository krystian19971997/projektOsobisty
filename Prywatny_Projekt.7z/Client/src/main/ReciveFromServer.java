package main;

class ReciveFromServer implements Runnable{

    private final Client client;

    public ReciveFromServer(Client client) {
        this.client = client;
    }

    @Override
    public void run() {
        String wiadomosc;
        try {
            while ((wiadomosc = client.bufferedReader.readLine())!=null){
                String subString[] = wiadomosc.split(":");
                if (!subString[0].equals(client.imie)) {
                    System.out.println(wiadomosc);
                    System.out.println(">> ");
                }
            }

        }catch (Exception e){
            System.out.println("polacznie zakonczone!");
        }
    }
}
