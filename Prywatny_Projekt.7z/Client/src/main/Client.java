package main;


import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    public static final int PORT = 7777;
    public static final String IP = "127.0.0.1";

    BufferedReader bufferedReader;
    String imie;

    //start programu
    public static void main(String[] args) {
        Client c = new Client();
        c.startClient();

    }

    //uruchomienie klienta
    public void startClient() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Podaj imie: ");
        //imie = sc.nextLine();
        while ((imie =sc.nextLine()).isEmpty() ) {
            System.out.print("podaj nazwe zgodna z baza | Pamiętaj, Twoja nazwa nie może być pusta");
        }

        try {

//            ReadFile r = new ReadFile();
//            System.out.print(imie);
//            r.pisz();
            Socket socket = new Socket(IP, PORT);
            System.out.println("podłaczono do: " + socket);

            PrintWriter printWriter = new PrintWriter(socket.getOutputStream());
            printWriter.println(imie);
            printWriter.flush();
            bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            Thread t = new Thread(new ReciveFromServer(this));
            t.start();
            while (true) {
                System.out.print(">> ");
                String str = sc.nextLine();
                if (!str.equalsIgnoreCase("q")) {
                    printWriter.println(imie + ":" + str);
                    printWriter.flush();

                } else {
                    printWriter.println(imie + " rozlaczyl sie");
                    printWriter.flush();
                    printWriter.close();
                    sc.close();
                    socket.close();
                }

            }
        } catch (Exception e) {

        }
    }

}
