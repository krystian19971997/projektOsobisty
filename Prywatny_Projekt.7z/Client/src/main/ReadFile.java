package main;

import java.io.BufferedReader;
import java.io.FileReader;

public class ReadFile
{

    static void pisz()  {
        String fileName = "src\\powitanie.txt";

        BufferedReader bf = null;
        try {
            bf = new BufferedReader(new FileReader(fileName));
            String linia = null;
            do{
                linia = bf.readLine();
                if(linia!=null){
                    System.out.println(linia);
                }
            }while (linia!=null);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}


