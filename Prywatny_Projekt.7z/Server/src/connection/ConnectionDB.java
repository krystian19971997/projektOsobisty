package connection;

import java.sql.Connection;
import java.sql.DriverManager;

class ConnectionDB {

       private static String URL = "jdbc:mysql://localhost/chat";
       private static String USER = "root";
       private static String  PASSWORD ="";

       public static Connection connect(){
           Connection connection = null;
           try {
               connection = DriverManager.getConnection(URL,USER,PASSWORD);
//               System.out.println("polaczono poprawnie");
           } catch (Exception e) {
               e.printStackTrace();
           }
           return connection;
       }


}