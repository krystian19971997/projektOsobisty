package main;

import connection.QueryExecutor;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;

//klasa wew
class ServerClient implements Runnable {
    private final Server server;
    Socket socket;
    BufferedReader bufferedReader, bufferedReader2;

    //konstruktor
    public ServerClient(Server server, Socket socketKlient) {
        this.server = server;
        try {
            socket = socketKlient;
            bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            bufferedReader2 = new BufferedReader(new InputStreamReader(socket.getInputStream()));

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public void run() {
        //to co wejdzie do buffereReadera
        String str;
        PrintWriter pw = null;
        String login_sended = null;
        String nazwa_z_bazy = null;
        try {
            login_sended = bufferedReader2.readLine();
            ResultSet result = QueryExecutor.executeSelect("Select imie from klient where imie='" + login_sended + "'");
            if (result.next()) {
                nazwa_z_bazy = result.getString("imie");
            }
            if (login_sended.equals(nazwa_z_bazy)) {
                System.out.println("Dane sa poprawne, witaj " + login_sended);
                while ((str = bufferedReader.readLine()) != null) {

                    System.out.println("odebrano od klienta: " + str);
                    Iterator iterator = server.clientArraylist.iterator();
                    while (iterator.hasNext()) {
                        pw = (PrintWriter) iterator.next();
                        pw.println(str);
                        pw.flush();
                    }
                }
            } else {
               System.out.println("Bledny login lub haslo, uruchom aplikacje jeszcze raz");
            }

        } catch (IOException | SQLException e) {
            System.out.println(login_sended +" wylogował się z serwera ");
            try {
                socket.close();
                pw.close();



            } catch (IOException ex) {
                ex.printStackTrace();
            }


        }
    }
}
