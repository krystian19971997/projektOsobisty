package main;

import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class Server {
    ArrayList clientArraylist;
    PrintWriter printWriter;
    //uruchomienie programu
    public static void main(String[] args) {
        Server s = new Server();
        s.startServer();
    }
    //start servera
    public void startServer(){
        System.out.println("server wystartowal!");
        clientArraylist = new ArrayList();
        try{
            ServerSocket serverSocket = new ServerSocket(7777);
            while (true){
                Socket socket = serverSocket.accept();
                System.out.println("Server slucham na porcie: "+serverSocket);
                printWriter = new PrintWriter(socket.getOutputStream());
                clientArraylist.add(printWriter);

                Thread t = new Thread(new ServerClient(this, socket));
                t.start();

            }

        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
